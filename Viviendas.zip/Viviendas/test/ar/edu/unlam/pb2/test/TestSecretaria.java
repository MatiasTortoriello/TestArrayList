package ar.edu.unlam.pb2.test;

import static org.junit.Assert.*;

import org.junit.Test;

import ar.edu.unlam.pb2.dominio.Habitante;
import ar.edu.unlam.pb2.dominio.Municipio;
import ar.edu.unlam.pb2.dominio.Secretaria;
import ar.edu.unlam.pb2.dominio.Vivienda;

public class TestSecretaria {

	@Test
	public void queSePuedaCrearUnaSecretaria() {
		Secretaria secretaria = new Secretaria("C�rdoba");
		assertNotNull(secretaria);
	}
	
	@Test
	public void queSePuedaAgregarUnHabitanteALaSecretaria(){
		Secretaria secretaria = new Secretaria("C�rdoba");
		Integer dni = 5;
		String nombre = "Pepito";
		String calle = "Tu vieja";
		Integer numero = 123;
		Integer numeroMunicipio = 1;
		String nombreMunicipio = "San Justo";
		
		Municipio municipio = new Municipio(numeroMunicipio, nombreMunicipio);
		Vivienda vivienda = new Vivienda(calle, numero, municipio);
		Habitante habitante = new Habitante(dni, nombre, vivienda);
		
		secretaria.registrarHabitante(habitante);
		
		Integer valorEsperado = 1;
		Integer valorObtenido = secretaria.obtenerCantidadHabitantes();
		assertEquals(valorEsperado, valorObtenido);
	}

}
