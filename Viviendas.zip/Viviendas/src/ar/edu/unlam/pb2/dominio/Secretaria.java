package ar.edu.unlam.pb2.dominio;

import java.util.ArrayList;

public class Secretaria {

	private String nombre;
	private ArrayList<Habitante> habitantes;
	
	public Secretaria(String nombre) {
		this.setNombre(nombre);
		habitantes = new ArrayList<>();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void registrarHabitante(Habitante habitante) {
		habitantes.add(habitante);
	}

	public Integer obtenerCantidadHabitantes() {
		return habitantes.size();
	}

}
