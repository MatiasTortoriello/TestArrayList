package ar.edu.unlam.pb2.dominio;

public class Habitante {
	
	private Integer dni;
	private String nombre;
	private Vivienda vivienda;

	public Habitante(Integer dni, String nombre, Vivienda vivienda) {
		this.dni = dni;
		this.nombre = nombre;
		this.vivienda = vivienda;
	}

}
