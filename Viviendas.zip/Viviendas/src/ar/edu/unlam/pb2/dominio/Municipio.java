package ar.edu.unlam.pb2.dominio;

public class Municipio {

	private Integer numeroMunicipio;
	private String nombreMunicipio;
	
	public Municipio(Integer numeroMunicipio, String nombreMunicipio) {
		this.numeroMunicipio = numeroMunicipio;
		this.nombreMunicipio = nombreMunicipio;
	}

}
